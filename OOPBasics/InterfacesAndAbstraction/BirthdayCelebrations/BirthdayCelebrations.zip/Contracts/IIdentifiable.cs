﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BirthdayCelebrations.Contracts
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
