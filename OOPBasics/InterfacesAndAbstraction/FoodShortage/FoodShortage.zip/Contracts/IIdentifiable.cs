﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortage.Contracts
{
    public interface IIdentifiable
    {
        string Id { get; }
    }
}
